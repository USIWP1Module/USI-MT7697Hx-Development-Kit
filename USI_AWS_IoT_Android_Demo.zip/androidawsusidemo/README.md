# Android AWS USI Demo

This sample is refer https://github.com/awslabs/aws-sdk-android-samples/tree/master/AndroidPubSub

