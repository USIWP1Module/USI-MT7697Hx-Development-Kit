package android.usidemo;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import org.json.JSONException;
import org.json.JSONObject;
import java.lang.ref.WeakReference;

import com.amazonaws.auth.CognitoCachingCredentialsProvider;
import com.amazonaws.mobile.client.AWSMobileClient;
import com.amazonaws.mobile.client.Callback;
import com.amazonaws.mobile.client.UserStateDetails;
import com.amazonaws.mobileconnectors.iot.AWSIotKeystoreHelper;
import com.amazonaws.mobileconnectors.iot.AWSIotMqttClientStatusCallback;
import com.amazonaws.mobileconnectors.iot.AWSIotMqttLastWillAndTestament;
import com.amazonaws.mobileconnectors.iot.AWSIotMqttManager;
import com.amazonaws.mobileconnectors.iot.AWSIotMqttNewMessageCallback;
import com.amazonaws.mobileconnectors.iot.AWSIotMqttQos;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.iot.AWSIotClient;
import com.amazonaws.services.iot.model.AttachPrincipalPolicyRequest;
import com.amazonaws.services.iot.model.CreateKeysAndCertificateRequest;
import com.amazonaws.services.iot.model.CreateKeysAndCertificateResult;

import java.io.UnsupportedEncodingException;
import java.security.KeyStore;
import java.util.UUID;


public class WiFiDemoActivity extends AppCompatActivity {
    private static final String TAG = "USI_WiFiDemoActivity";
    void logcat(String logStr) {
        Log.v(TAG, String.format("PID[%d], TID[%d] :  %s", android.os.Process.myPid(), android.os.Process.myTid(), logStr));
    }

    // IoT endpoint
    // AWS Iot CLI describe-endpoint call returns: XXXXXXXXXX.iot.<region>.amazonaws.com
    private static final String CUSTOMER_SPECIFIC_ENDPOINT = "Your AWS IoT endpoint";
    // Name of the AWS IoT policy to attach to a newly created certificate
    private static final String AWS_IOT_POLICY_NAME = "Your AWS IoT policy";

    // Region of AWS IoT, ex: Regions.US_EAST_2
    private static final Regions MY_REGION = Regions.Your AWS IoT Region;
    // Filename of KeyStore file on the filesystem
    private static final String KEYSTORE_NAME = "iot_keystore";
    // Password for the private key in the KeyStore
    private static final String KEYSTORE_PASSWORD = "password";
    // Certificate and key aliases in the KeyStore
    private static final String CERTIFICATE_ID = "default_certid";

    private static final String PUBLISH_TOPIC ="Your LED TOPIC";
    private static final String SUBSCRIBE_TOPIC ="Your Sensor TOPIC";

    RadioGroup btnLedGroup=null;
    RadioButton btnLedOff=null;
    RadioButton btnLedWhite=null;
    RadioButton btnLedRed=null;
    RadioButton btnLedBlue=null;
    RadioButton btnLedGreen=null;
    RadioButton btnLedYellow=null;

    TextView txtVwDeviceConnectionStatus = null;
    TextView txtVwAwsIoTConnectionStatus = null;
    TextView txtVwSensorRanging = null;
    TextView txtVwSensorTemperature = null;
    TextView txtVwSensorHumidity = null;

    String strAwsIoTValue = null;
    String strRangingValue = null;
    String strTemperatureValue = null;
    String strHumidityValue = null;

    AWSIotClient mIotAndroidClient;
    AWSIotMqttManager mqttManager;
    String clientId;
    String keystorePath;
    String keystoreName;
    String keystorePassword;

    KeyStore clientKeyStore = null;
    String certificateId;
    boolean isAlive = false;
    long recvDevMsgTime = 0;

    public static final String CMD_LED_OFF            = "off";
    public static final String CMD_LED_WHITE          = "white";
    public static final String CMD_LED_RED            = "red";
    public static final String CMD_LED_BLUE           = "blue";
    public static final String CMD_LED_GREEN          = "green";
    public static final String CMD_LED_YELLOW         = "yellow";

    private WiFiDemoActivity.LedOnCheckedChangeListener ledChkListener = new WiFiDemoActivity.LedOnCheckedChangeListener();

    private class LedOnCheckedChangeListener implements RadioGroup.OnCheckedChangeListener {
        @Override
        public void onCheckedChanged(RadioGroup group,int checkedId){
            if(btnLedOff.getId()==checkedId){
                //logcat("btnLedOff");
                publishTopic(PUBLISH_TOPIC, CMD_LED_OFF);
            }
            else if(btnLedWhite.getId()==checkedId){
                //logcat("btnLedWhite");
                publishTopic(PUBLISH_TOPIC, CMD_LED_WHITE);
            }
            else if(btnLedRed.getId()==checkedId){
                //logcat("btnLedRed");
                publishTopic(PUBLISH_TOPIC, CMD_LED_RED);
            }
            else if(btnLedBlue.getId()==checkedId){
                //logcat("btnLedBlue");
                publishTopic(PUBLISH_TOPIC, CMD_LED_BLUE);
            }
            else if(btnLedGreen.getId()==checkedId){
                //logcat("btnLedGreen");
                publishTopic(PUBLISH_TOPIC, CMD_LED_GREEN);
            }
            else if(btnLedYellow.getId()==checkedId){
                //logcat("btnLedYellow");
                publishTopic(PUBLISH_TOPIC, CMD_LED_YELLOW);
            }
            else{
                logcat("Unknown LED button ID");
            }
        }

    }

    // check network connection
    public boolean checkNetworkConnection() {
        ConnectivityManager connMgr = (ConnectivityManager)
                getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        boolean isConnected = false;
        if (networkInfo != null && (isConnected = networkInfo.isConnected())) {
            logcat("Android Network is Connected, Name:"+networkInfo.getSubtypeName());
        } else {
            logcat("Android Network not Connected !");
        }

        return isConnected;
    }

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wifi_demo);

        try{
            isAlive = true;
            deviceConnectionStatusTimer();

            initView();

            if(checkNetworkConnection()){
                // MQTT client IDs are required to be unique per AWS IoT account.
                // This UUID is "practically unique" but does not _guarantee_
                // uniqueness.
                clientId = UUID.randomUUID().toString();
                logcat("Client Id: " + clientId);

                // Initialize the AWS Cognito credentials provider
                AWSMobileClient.getInstance().initialize(this, new Callback<UserStateDetails>() {
                    @Override
                    public void onResult(UserStateDetails result) {
                        initAWSIoT();
                    }

                    @Override
                    public void onError(Exception e) {
                        logcat("onError: " + e.toString());
                    }
                });
            }else{
                Toast.makeText(this, "Network connection fail.\nPlease connect to network.", Toast.LENGTH_LONG).show();
                final Intent intent = new Intent(this, SplashScreenActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent);
            }

        }catch (Exception e) {
            logcat("Exception create: " + e.toString());
        }

    }


    @Override
    protected void onDestroy() {
        logcat("\n\n=============== onDestroy() ===============\n\n");
        try{
            isAlive = false;
        }catch (Exception e) {
            logcat("Exception onDestroy: " + e.toString());
        }
        super.onDestroy();
    }

    private void initView(){
        try{
            final Toolbar toolbar = findViewById(R.id.toolbar);
            setSupportActionBar(toolbar);
            getSupportActionBar().setTitle(R.string.app_name);

            btnLedGroup=(RadioGroup)super.findViewById(R.id.btn_led_group);
            btnLedOff=(RadioButton)super.findViewById(R.id.btn_led_off);
            btnLedWhite=(RadioButton)super.findViewById(R.id.btn_led_white);
            btnLedRed=(RadioButton)super.findViewById(R.id.btn_led_red);
            btnLedBlue=(RadioButton)super.findViewById(R.id.btn_led_blue);
            btnLedGreen=(RadioButton)super.findViewById(R.id.btn_led_green);
            btnLedYellow=(RadioButton)super.findViewById(R.id.btn_led_yellow);

            btnLedGroup.setOnCheckedChangeListener(ledChkListener);

            txtVwDeviceConnectionStatus = (TextView)findViewById(R.id.device_connection_status);
            txtVwAwsIoTConnectionStatus = (TextView)findViewById(R.id.aws_connection_status);
            txtVwSensorRanging = (TextView)findViewById(R.id.sensor_ranging);
            txtVwSensorTemperature = (TextView)findViewById(R.id.sensor_temperature);
            txtVwSensorHumidity = (TextView)findViewById(R.id.sensor_humidity);
        }catch (Exception e) {
            logcat("Exception initView : " + e.toString());
        }

    }

    private void initAWSIoT() {
        Region region = Region.getRegion(MY_REGION);

        // MQTT Client
        mqttManager = new AWSIotMqttManager(clientId, CUSTOMER_SPECIFIC_ENDPOINT);

        // Set keepalive to 10 seconds.  Will recognize disconnects more quickly but will also send
        // MQTT pings every 10 seconds.
        mqttManager.setKeepAlive(10);

        // Set Last Will and Testament for MQTT.  On an unclean disconnect (loss of connection)
        // AWS IoT will publish this message to alert other clients.
        AWSIotMqttLastWillAndTestament lwt = new AWSIotMqttLastWillAndTestament("my/lwt/topic",
                "Android client lost connection", AWSIotMqttQos.QOS0);
        mqttManager.setMqttLastWillAndTestament(lwt);

        // IoT Client (for creation of certificate if needed)
        mIotAndroidClient = new AWSIotClient(AWSMobileClient.getInstance());
        mIotAndroidClient.setRegion(region);

        keystorePath = getFilesDir().getPath();
        keystoreName = KEYSTORE_NAME;
        keystorePassword = KEYSTORE_PASSWORD;
        certificateId = CERTIFICATE_ID;

        logcat("keystore Path: " + keystorePath);
        // To load cert/key from keystore on filesystem
        try {
            if (AWSIotKeystoreHelper.isKeystorePresent(keystorePath, keystoreName)) {
                if (AWSIotKeystoreHelper.keystoreContainsAlias(certificateId, keystorePath,
                        keystoreName, keystorePassword)) {
                    logcat("Certificate " + certificateId
                            + " found in keystore - using for MQTT.");
                    // load keystore from file into memory to pass on connection
                    clientKeyStore = AWSIotKeystoreHelper.getIotKeystore(certificateId,
                            keystorePath, keystoreName, keystorePassword);
                    /* initIoTClient is invoked from the callback passed during AWSMobileClient initialization.
                    The callback is executed on a background thread so UI update must be moved to run on UI Thread. */
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            logcat("AWS IoT Certificate verify success!");
                            connectAWSIoT();
                        }
                    });
                } else {
                    logcat( "Key/cert " + certificateId + " not found in keystore.");
                }
            } else {
                logcat("Keystore " + keystorePath + "/" + keystoreName + " not found.");
            }
        } catch (Exception e) {
            logcat( "An error occurred retrieving cert/key from keystore.\n"+ e.toString());
        }

        if (clientKeyStore == null) {
            logcat("Cert/key was not found in keystore - creating new key and certificate.");

            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        // Create a new private key and certificate. This call
                        // creates both on the server and returns them to the
                        // device.
                        CreateKeysAndCertificateRequest createKeysAndCertificateRequest =
                                new CreateKeysAndCertificateRequest();
                        createKeysAndCertificateRequest.setSetAsActive(true);
                        final CreateKeysAndCertificateResult createKeysAndCertificateResult;
                        createKeysAndCertificateResult =
                                mIotAndroidClient.createKeysAndCertificate(createKeysAndCertificateRequest);
                        logcat("Cert ID: " +
                                        createKeysAndCertificateResult.getCertificateId() +
                                        " created.");

                        // store in keystore for use in MQTT client
                        // saved as alias "default" so a new certificate isn't
                        // generated each run of this application
                        AWSIotKeystoreHelper.saveCertificateAndPrivateKey(certificateId,
                                createKeysAndCertificateResult.getCertificatePem(),
                                createKeysAndCertificateResult.getKeyPair().getPrivateKey(),
                                keystorePath, keystoreName, keystorePassword);

                        // load keystore from file into memory to pass on
                        // connection
                        clientKeyStore = AWSIotKeystoreHelper.getIotKeystore(certificateId,
                                keystorePath, keystoreName, keystorePassword);

                        // Attach a policy to the newly created certificate.
                        // This flow assumes the policy was already created in
                        // AWS IoT and we are now just attaching it to the
                        // certificate.
                        AttachPrincipalPolicyRequest policyAttachRequest =
                                new AttachPrincipalPolicyRequest();
                        policyAttachRequest.setPolicyName(AWS_IOT_POLICY_NAME);
                        policyAttachRequest.setPrincipal(createKeysAndCertificateResult
                                .getCertificateArn());
                        mIotAndroidClient.attachPrincipalPolicy(policyAttachRequest);

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                logcat("AWS IoT Certificate verify success!");
                                connectAWSIoT();
                            }
                        });
                    } catch (Exception e) {
                        logcat("Exception occurred when generating new private key and certificate.\n"+
                                e.toString());
                    }
                }
            }).start();
        }
    }


    public void connectAWSIoT() {
        logcat("clientId = " + clientId);

        try {
            mqttManager.connect(clientKeyStore, new AWSIotMqttClientStatusCallback() {
                @Override
                public void onStatusChanged(final AWSIotMqttClientStatus status,
                                            final Throwable throwable) {
                    logcat("Status = " + String.valueOf(status));
                    strAwsIoTValue = String.valueOf(status);

                    //Update AWS IoT connection status
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            txtVwAwsIoTConnectionStatus.setText(strAwsIoTValue);

                            if(String.valueOf(status).equals("Connected")){
                                subscribeTopic(SUBSCRIBE_TOPIC);
                                txtVwAwsIoTConnectionStatus.setTextColor(getResources().getColor(R.color.green));
                            }else if(String.valueOf(status).equals("Disconnect")){
                                txtVwAwsIoTConnectionStatus.setTextColor(getResources().getColor(R.color.red));
                            }else{
                                txtVwAwsIoTConnectionStatus.setTextColor(getResources().getColor(R.color.black));
                            }
                        }
                    });

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (throwable != null) {
                                logcat("Connection error : "+ throwable);
                            }
                        }
                    });
                }
            });
        } catch (final Exception e) {
            logcat("Connection error."+ e.toString());
        }
    }

    /*
     *   MQTT Publish Message example
     *   {"ledColor":"white"}
     */
    public void publishTopic(String topic , String msg) {
        try {
            String pubmsg = "{\"ledColor\":\""+msg+"\"}";
            logcat("Publish Topic:"+topic+"\nMSG:"+pubmsg);
            mqttManager.publishString(pubmsg, topic, AWSIotMqttQos.QOS0);
        } catch (Exception e) {
            logcat("Publish error.\n"+ e.toString());
        }
    }

    public void subscribeTopic(final String topic) {
        logcat( "Subscribe Topic = " + topic);

        try {
            mqttManager.subscribeToTopic(topic, AWSIotMqttQos.QOS0,
                    new AWSIotMqttNewMessageCallback() {
                        @Override
                        public void onMessageArrived(final String topic, final byte[] data) {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    try {
                                        String message = new String(data, "UTF-8");
                                        logcat( "Message arrived:");
                                        logcat( "   Topic: " + topic);
                                        logcat( " Message: " + message);
                                        processReceiveMessages(topic,message);

                                    } catch (UnsupportedEncodingException e) {
                                        logcat("Message encoding error : "+ e.toString());
                                    }
                                }
                            });
                        }
                    });
        } catch (Exception e) {
            logcat("Subscription error : "+ e.toString());
        }
    }



    private void processReceiveMessages(String topic,String msg){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    logcat("Recv topic : " + topic);
                    logcat("Recv msg : "   + msg);

                    if (topic.equals(SUBSCRIBE_TOPIC)) {

                        recvDevMsgTime = System.currentTimeMillis();

                        JSONObject jsonObject = new JSONObject(msg);
                        strRangingValue = jsonObject.getString("ranging");
                        //logcat("strRangingValue:" + strRangingValue);
                        if(!strRangingValue.equals("0"))
                            txtVwSensorRanging.setText(getString(R.string.data_ranging, strRangingValue));

                        strHumidityValue = jsonObject.getString("humidity");
                        //logcat("strHumidityValue:" + strHumidityValue);
                        if(!strHumidityValue.equals("0"))
                            txtVwSensorHumidity.setText(getString(R.string.data_humidity, strHumidityValue) + " %");

                        strTemperatureValue = jsonObject.getString("temperature");
                        //logcat("strTemperatureValue:" + strTemperatureValue);
                        if(!strTemperatureValue.equals("0"))
                            txtVwSensorTemperature.setText(getString(R.string.data_temperature, strTemperatureValue));
                    }

                }catch (Exception e) {
                    logcat("Exception processReceiveMessages: " + e.toString());
                }
            }
        });
    }

    private void deviceConnectionStatusTimer(){
        new Thread( new Runnable() {
            public void run() {
                try {
                    while(isAlive){
                        checkDeviceConnection();
                        Thread.sleep(1000);
                    }
                }catch (Exception e) {
                    logcat("Exception deviceConnectionStatusTimer: " + e.toString());
                }

            }
        }).start();
    }


    private void checkDeviceConnection(){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    //Over 10 sec not recv MQTT message
                    if( ((System.currentTimeMillis() - recvDevMsgTime) > 10000) || (recvDevMsgTime == 0) ){
                        //logcat("Device Disconnect:"+System.currentTimeMillis());
                        txtVwDeviceConnectionStatus.setText("Disconnect");
                        txtVwDeviceConnectionStatus.setTextColor(getResources().getColor(R.color.red));
                        btnLedOff.setEnabled(false);
                        btnLedWhite.setEnabled(false);
                        btnLedRed.setEnabled(false);
                        btnLedBlue.setEnabled(false);
                        btnLedGreen.setEnabled(false);
                        btnLedYellow.setEnabled(false);
                    }else{
                        //logcat("Device Connected:"+System.currentTimeMillis());
                        txtVwDeviceConnectionStatus.setText("Connected");
                        txtVwDeviceConnectionStatus.setTextColor(getResources().getColor(R.color.green));
                        btnLedOff.setEnabled(true);
                        btnLedWhite.setEnabled(true);
                        btnLedRed.setEnabled(true);
                        btnLedBlue.setEnabled(true);
                        btnLedGreen.setEnabled(true);
                        btnLedYellow.setEnabled(true);
                    }
                }catch (Exception e) {
                    logcat("Exception check Device Connection : " + e.toString());
                }
            }
        });
    }

}
